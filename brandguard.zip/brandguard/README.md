# BrandGuard

Pre-publication brand review. Content goes in, it is checked against an organisation's approved guidelines,
terms, facts and assets, every issue comes back explained with its source, and a human decides.
Built for the Inkloom AI brand-governance problem statement.

The demo organisation, **Tarang Mobile**, and all its plans, prices and evidence are invented.

## The central path

1. **Submit** copy (paste, or import `.txt`, `.md`, `.docx`, `.pdf`) and optionally images.
2. **Check.** The engine compares it with the Brand kit and raises findings in six areas: terminology, tone,
   claims, facts, accessibility, visual identity.
3. **Explain.** Each finding shows what is wrong, the guideline it breaks, the approved fact / term / evidence
   entry behind it, a confidence figure and a suggested fix that keeps the creator's meaning.
4. **Decide.** The creator accepts, edits or dismisses every finding (a dismissal needs a reason). Nothing is
   applied automatically. Accepted fixes become a new version, which is re-checked.
5. **Approve.** Submit for review. A reviewer or brand manager approves or requests changes (feedback required).
   High-severity findings that were dismissed, or marked "I will fix this" but are still present, need the
   reviewer's explicit sign-off.
6. **Learn.** Insights show the most repeated mistakes and which guidelines creators keep dismissing as unclear.

## Run it

Open `dist/brandguard.html` in a browser. No server, no install, no network.

```
node scripts/build.js                 # rebuild dist/brandguard.html from src/ and vendor/
node tests/engine.test.js             # 21 engine tests
python3 tests/make_fixtures.py        # sample PDF / DOCX / PNG (needs reportlab, python-docx, pillow)
node tests/e2e.js                     # 33 browser checks (needs Playwright + Chromium)
```

## Architecture

| File | Role |
| --- | --- |
| `src/engine.js` | Pure review engine. Text in, findings out. Every finding names its guideline and source entry. Runs in the browser and in Node. |
| `src/kit.js` | The sample Brand kit: guidelines, terms, claim rules, evidence (with status and expiry), plan-sheet facts, palette, fonts, logo rules. A manager can edit it or import a kit as JSON. |
| `src/app.js` | UI, roles, versions, decisions, approval gates, comments, activity log, insights. State is kept in `localStorage`. |
| `vendor/` | JSZip (read `.docx`) and pdf.js (read `.pdf`), bundled so the page makes no network requests. |

Main technical decisions:

- **Rules, not a language model.** Matching is by explicit patterns tied to kit entries, so results are
  repeatable and every one can be traced to a source. This is the reliability choice; its cost is that
  paraphrased claims and subtle tone are missed.
- **Evidence has a lifecycle.** A ranking claim is supported only by approved, in-scope, unexpired evidence.
- **Human control is enforced in the workflow**, not just the wording: no auto-apply, reasons on dismissal,
  submission blocked until every finding has a decision, reviewer sign-off on high-severity exceptions.
- **Local-only.** Content never leaves the browser.

## Libraries and services used (disclosure)

| Item | Use | Licence |
| --- | --- | --- |
| JSZip 3.10.1 | Reading `.docx` | MIT |
| pdf.js 3.11.174 | Reading `.pdf` | Apache-2.0 |
| Playwright | Browser tests only | Apache-2.0 |

No AI model and no external service runs inside the product. **The code was written with AI coding assistance
(Claude).** State this in the submission form (rule 7). Teams must also confirm the work falls inside the official
build window (rule 1) and disclose any code that predates it (rule 6).

## Known limitations

- Single browser, no accounts: the three people in the sign-in menu are demo roles, and data lives in
  `localStorage`. Multi-user storage, real authentication and per-organisation isolation are not built.
- Images are checked from size, dominant colours and the details entered (use, alt text, colours), not by reading
  the picture. Text inside images is not read. Scanned PDFs have no text layer.
- Tone is judged by word lists, exclamation marks, capitals and sentence length.
- A claim is matched by its wording. A differently worded claim is not caught.

## Roadmap

1. Server storage with real sign-in and one workspace per organisation.
2. A language model for paraphrased claims and tone, restricted to retrieved kit entries, with every suggestion
   grounded in a quoted source and a clear "no approved source found" state.
3. Image understanding (read text in images, detect the logo and check its clear space).
4. Kit ingestion from uploaded brand-guide PDFs, with a manager confirming each extracted rule.
