/* BrandGuard review engine.
 * Pure functions, no network, no DOM. Every finding carries the guideline or
 * approved source that produced it, so a reviewer can always see why.
 * Works in the browser (window.BG) and in Node (require). */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else { root.BG = root.BG || {}; Object.assign(root.BG, factory()); }
})(typeof self !== 'undefined' ? self : this, function () {
  const SEV_RANK = { high: 3, medium: 2, low: 1 };

  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  function matchCase(src, rep) {
    if (!rep) return rep;
    if (/^[A-Z]/.test(src)) return rep[0].toUpperCase() + rep.slice(1);
    return rep;
  }

  function sentences(text) {
    const out = [];
    const n = text.length;
    const push = (s, e) => {
      let a = s, b = e;
      while (a < b && /\s/.test(text[a])) a++;
      while (b > a && /\s/.test(text[b - 1])) b--;
      if (b > a) out.push({ start: a, end: b, text: text.slice(a, b) });
    };
    let start = 0;
    for (let i = 0; i < n; i++) {
      const c = text[i];
      const isEnd = c === '\n' || ((c === '.' || c === '!' || c === '?') && (i + 1 === n || /\s/.test(text[i + 1])));
      if (isEnd) {
        let j = i + 1;
        while (j < n && /[.!?]/.test(text[j]) && c !== '\n') j++;
        push(start, j);
        start = j;
        i = j - 1;
      }
    }
    push(start, n);
    return out;
  }

  function sentenceAt(sents, pos) {
    return sents.find((s) => pos >= s.start && pos < s.end) || sents[sents.length - 1] || { start: 0, end: 0, text: '' };
  }

  function mk(o) {
    return Object.assign({ confidence: 0.9, suggestion: null, start: null, end: null }, o);
  }

  /* ---------- colour helpers ---------- */
  function hexToRgb(hex) {
    let h = String(hex || '').replace('#', '').trim();
    if (h.length === 3) h = h.split('').map((c) => c + c).join('');
    if (!/^[0-9a-fA-F]{6}$/.test(h)) return null;
    return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
  }
  function rgbToHex(r, g, b) {
    return '#' + [r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('').toUpperCase();
  }
  function relLum(rgb) {
    const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
    return 0.2126 * f(rgb[0]) + 0.7152 * f(rgb[1]) + 0.0722 * f(rgb[2]);
  }
  function contrast(hexA, hexB) {
    const a = hexToRgb(hexA), b = hexToRgb(hexB);
    if (!a || !b) return null;
    const la = relLum(a), lb = relLum(b);
    return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
  }
  function hsl(rgb) {
    const [r, g, b] = rgb.map((v) => v / 255);
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2;
    const d = mx - mn;
    const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
    return { s, l };
  }
  function rgbDist(a, b) {
    return Math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2);
  }

  /* ---------- checks on text ---------- */
  function checkTerminology(text, kit) {
    const out = [];
    for (const t of kit.terms || []) {
      for (const a of t.avoid) {
        const plural = t.noPlural ? '' : '(s)?';
        const re = new RegExp('(?<![\\w-])' + esc(a) + plural + '(?![\\w-])', 'gi');
        for (const m of text.matchAll(re)) {
          const start = m.index, end = start + m[0].length;
          let rep = matchCase(m[0], t.preferred);
          if (m[1]) rep += 's';
          out.push(mk({
            rule: 'terminology', category: 'terminology', severity: 'medium',
            refType: 'term', refId: t.id, guidelineId: t.guideline,
            start, end, excerpt: m[0],
            message: '"' + m[0] + '" is not the approved term',
            why: 'Brand copy uses "' + t.preferred + '" instead of "' + a + '". ' + (t.note || ''),
            suggestion: { start, end, replacement: rep }, confidence: 0.95
          }));
        }
      }
    }
    return out;
  }

  function checkTone(text, kit, sents) {
    const out = [];
    const tone = kit.tone || {};
    for (const b of tone.banned || []) {
      const re = new RegExp('(?<![\\w-])' + esc(b.word) + '(?![\\w-])', 'gi');
      for (const m of text.matchAll(re)) {
        const start = m.index, end = start + m[0].length;
        out.push(mk({
          rule: 'tone.banned', category: 'tone', severity: 'low',
          refType: 'rule', refId: 'tone:' + b.word, guidelineId: 'G-1',
          start, end, excerpt: m[0],
          message: '"' + m[0] + '" does not match the brand voice',
          why: b.why + ' The voice guideline asks for warm, plain wording.',
          suggestion: { start, end, replacement: matchCase(m[0], b.replacement) }, confidence: 0.85
        }));
      }
    }
    // exclamation marks: first N runs allowed, a run longer than one mark is always trimmed
    let seen = 0;
    const maxEx = tone.maxExclaim == null ? 1 : tone.maxExclaim;
    for (const m of text.matchAll(/!+/g)) {
      seen++;
      const start = m.index, end = start + m[0].length;
      if (seen > maxEx) {
        out.push(mk({
          rule: 'tone.exclaim', category: 'tone', severity: 'low',
          refType: 'guideline', refId: 'G-5', guidelineId: 'G-5',
          start, end, excerpt: m[0],
          message: 'Too many exclamation marks (limit ' + maxEx + ' per piece)',
          why: 'This is exclamation mark number ' + seen + '. The guideline allows ' + maxEx + '.',
          suggestion: { start, end, replacement: '.' }, confidence: 0.9
        }));
      } else if (m[0].length > 1) {
        out.push(mk({
          rule: 'tone.exclaim', category: 'tone', severity: 'low',
          refType: 'guideline', refId: 'G-5', guidelineId: 'G-5',
          start, end, excerpt: m[0],
          message: 'Repeated exclamation marks',
          why: 'Use a single exclamation mark at most.',
          suggestion: { start, end, replacement: '!' }, confidence: 0.9
        }));
      }
    }
    const allowed = new Set((tone.allowedAcronyms || []).map((s) => s.toUpperCase()));
    for (const m of text.matchAll(/\b[A-Z]{4,}\b/g)) {
      if (allowed.has(m[0])) continue;
      const start = m.index, end = start + m[0].length;
      out.push(mk({
        rule: 'tone.caps', category: 'tone', severity: 'low',
        refType: 'guideline', refId: 'G-5', guidelineId: 'G-5',
        start, end, excerpt: m[0],
        message: '"' + m[0] + '" is written in capitals',
        why: 'ALL-CAPS reads as shouting and is harder to read with a screen reader. Approved acronyms are exempt.',
        suggestion: { start, end, replacement: m[0][0] + m[0].slice(1).toLowerCase() }, confidence: 0.8
      }));
    }
    const maxW = tone.maxSentenceWords || 25;
    for (const s of sents) {
      const words = s.text.split(/\s+/).filter(Boolean).length;
      if (words > maxW) {
        out.push(mk({
          rule: 'clarity.long', category: 'tone', severity: 'low',
          refType: 'guideline', refId: 'G-9', guidelineId: 'G-9',
          start: s.start, end: s.end, excerpt: s.text.length > 70 ? s.text.slice(0, 67) + '...' : s.text,
          message: 'Sentence has ' + words + ' words (limit ' + maxW + ')',
          why: 'Long sentences are harder to scan on a phone. Split it where the idea changes.',
          suggestion: null, advice: 'Split this into two sentences. The tool does not rewrite meaning on its own.', confidence: 0.75
        }));
      }
    }
    return out;
  }

  function todayISO(opts) {
    return (opts && opts.today) || new Date().toISOString().slice(0, 10);
  }

  function checkClaims(text, kit, sents, opts) {
    const out = [], verified = [];
    const today = todayISO(opts);
    const disclaimerDone = new Set();
    for (const r of kit.claimRules || []) {
      const re = new RegExp(r.pattern, r.flags || 'gi');
      for (const m of text.matchAll(re)) {
        const start = m.index, end = start + m[0].length;
        const sent = sentenceAt(sents, start);
        if (r.requires === 'disclaimer') {
          if (disclaimerDone.has(r.id)) continue;
          disclaimerDone.add(r.id);
          if (new RegExp(esc(r.disclaimer), 'i').test(text)) {
            verified.push({ rule: 'claims.disclaimer', refId: r.id, guidelineId: r.guideline, excerpt: m[0], note: 'Required qualifier "' + r.disclaimer + '" is present.' });
            continue;
          }
          const endsPunct = /[.!?]$/.test(sent.text);
          out.push(mk({
            rule: 'claims.disclaimer', category: 'claims', severity: 'medium',
            refType: 'claimRule', refId: r.id, guidelineId: r.guideline,
            start, end, excerpt: m[0],
            message: '"' + m[0] + '" needs the qualifier "' + r.disclaimer + '"',
            why: 'Guideline ' + r.guideline + ' requires this qualifier wherever the word appears.',
            suggestion: { start: sent.end, end: sent.end, replacement: (endsPunct ? ' ' : '. ') + r.disclaimer + '.' }, confidence: 0.95
          }));
          continue;
        }
        const ev = (kit.evidence || []).filter((e) => e.topic === r.topic);
        const live = ev.find((e) => e.status === 'approved' && (!e.expires || e.expires >= today));
        const expired = ev.find((e) => e.status === 'approved' && e.expires && e.expires < today);
        const withdrawn = ev.find((e) => e.status === 'withdrawn');
        if (live) {
          const qualified = live.requiredText && new RegExp(esc(live.requiredText), 'i').test(sent.text);
          if (qualified) {
            verified.push({ rule: 'claims.superlative', refId: live.id, guidelineId: r.guideline, excerpt: m[0], note: 'Backed by ' + live.id + ' (' + live.source + ').' });
          } else {
            const endsPunct = /[.!?]$/.test(sent.text);
            out.push(mk({
              rule: 'claims.qualifier', category: 'claims', severity: 'medium',
              refType: 'evidence', refId: live.id, guidelineId: r.guideline,
              start, end, excerpt: m[0],
              message: '"' + m[0] + '" is approved only with its qualifier',
              why: 'Evidence ' + live.id + ' supports this claim for ' + live.scope + ' (' + live.source + ', valid to ' + live.expires + '). The qualifier must travel with the claim.',
              suggestion: { start: sent.end, end: sent.end, replacement: (endsPunct ? ' ' : '. ') + live.approvedWording }, confidence: 0.9
            }));
          }
        } else {
          let why = 'No approved evidence entry exists for this ' + r.label + '.';
          let src = { refType: 'claimRule', refId: r.id };
          if (expired) { why = 'Evidence ' + expired.id + ' (' + expired.source + ') expired on ' + expired.expires + '.'; src = { refType: 'evidence', refId: expired.id }; }
          else if (withdrawn) { why = 'Evidence ' + withdrawn.id + ' was withdrawn: ' + withdrawn.source + '.'; src = { refType: 'evidence', refId: withdrawn.id }; }
          out.push(mk(Object.assign({
            rule: 'claims.unsupported', category: 'claims', severity: 'high', guidelineId: r.guideline,
            start, end, excerpt: m[0],
            message: 'Unsupported claim: "' + m[0] + '"',
            why: why + ' Guideline ' + r.guideline + ' does not allow it without current evidence.',
            suggestion: { start, end, replacement: matchCase(m[0], r.soft) }, confidence: 0.9
          }, src)));
        }
      }
    }
    return { findings: out, verified };
  }

  const AMOUNT = /(?:₹|Rs\.?|INR)\s?(\d[\d,]*)/i;
  const AMOUNT_END = /(?:₹|Rs\.?|INR)\s?(\d[\d,]*)\s*$/i;
  const inr = (n) => '₹' + Number(n).toLocaleString('en-IN');

  function checkFacts(text, kit) {
    const out = [], verified = [];
    for (const f of kit.facts || []) {
      for (const a of f.aliases) {
        const re = new RegExp('(?<![\\w-])' + esc(a) + '(?![\\w-])', 'gi');
        for (const m of text.matchAll(re)) {
          const aStart = m.index, aEnd = aStart + m[0].length;
          if (f.status === 'retired') {
            out.push(mk({
              rule: 'facts.retired', category: 'facts', severity: 'high',
              refType: 'fact', refId: f.id, guidelineId: 'G-4',
              start: aStart, end: aEnd, excerpt: m[0],
              message: '"' + m[0] + '" is a retired plan',
              why: f.name + ' is retired (' + f.source + '). Guideline G-4 forbids quoting retired plans.',
              suggestion: f.replacementName ? { start: aStart, end: aEnd, replacement: matchCase(m[0], f.replacementName) } : null,
              advice: f.replacementName ? null : 'Remove the reference.', confidence: 0.95
            }));
            continue;
          }
          let after = text.slice(aEnd, aEnd + 70);
          const cut = after.search(/[.!?]\s|\n/);
          if (cut >= 0) after = after.slice(0, cut + 1);
          let amt = after.match(AMOUNT), amtBase = aEnd;
          if (!amt) {
            const bStart = Math.max(0, aStart - 14);
            const mb = text.slice(bStart, aStart).match(AMOUNT_END);
            if (mb) { amt = mb; amtBase = bStart; }
          }
          if (amt && f.price != null) {
            const num = Number(amt[1].replace(/,/g, ''));
            const s = amtBase + amt.index, e = s + amt[0].length;
            if (num !== f.price) {
              out.push(mk({
                rule: 'facts.price', category: 'facts', severity: 'high',
                refType: 'fact', refId: f.id, guidelineId: 'G-4',
                start: s, end: e, excerpt: amt[0],
                message: 'Price does not match the plan sheet: ' + inr(num) + ' vs ' + inr(f.price),
                why: f.name + ' costs ' + inr(f.price) + ' (' + f.source + ').',
                suggestion: { start: s, end: e, replacement: inr(f.price) }, confidence: 0.92
              }));
            } else verified.push({ rule: 'facts.price', refId: f.id, guidelineId: 'G-4', excerpt: amt[0], note: f.name + ' price matches ' + f.source + '.' });
          }
          const vd = after.match(/(\d+)\s*-?\s*days?\b/i);
          if (vd && f.validityDays != null) {
            const num = Number(vd[1]);
            const s = aEnd + vd.index, e = s + vd[0].length;
            if (num !== f.validityDays) {
              out.push(mk({
                rule: 'facts.validity', category: 'facts', severity: 'high',
                refType: 'fact', refId: f.id, guidelineId: 'G-4',
                start: s, end: e, excerpt: vd[0],
                message: 'Validity does not match the plan sheet: ' + num + ' vs ' + f.validityDays + ' days',
                why: f.name + ' is valid for ' + f.validityDays + ' days (' + f.source + ').',
                suggestion: { start: s, end: e, replacement: f.validityDays + (/-/.test(vd[0]) ? '-day' : ' days') }, confidence: 0.9
              }));
            } else verified.push({ rule: 'facts.validity', refId: f.id, guidelineId: 'G-4', excerpt: vd[0], note: f.name + ' validity matches ' + f.source + '.' });
          }
        }
      }
    }
    return { findings: out, verified };
  }

  function checkAlt(alt, ctx) {
    const a = (alt || '').trim();
    const base = { category: 'accessibility', refType: 'guideline', refId: 'G-7', guidelineId: 'G-7' };
    if (!a) return mk(Object.assign({}, base, {
      rule: 'a11y.alt-missing', severity: 'high', excerpt: ctx.excerpt,
      message: 'Image has no alt text', why: 'Screen-reader users get nothing from this image. G-7 requires meaningful alt text.',
      advice: 'Describe what the image shows and why it is there, in under 125 characters.', start: ctx.start, end: ctx.end, confidence: 0.98
    }));
    if (/^(image|img|photo|picture|graphic|banner|logo)\d*$/i.test(a) || /\.(png|jpe?g|gif|webp|svg)$/i.test(a) || /^(img|dsc|screenshot)[_\- ]?\d+/i.test(a)) return mk(Object.assign({}, base, {
      rule: 'a11y.alt-generic', severity: 'medium', excerpt: ctx.excerpt,
      message: 'Alt text "' + a + '" does not describe the image', why: 'Generic words and file names are not useful to a screen-reader user.',
      advice: 'Replace with a short description of what is shown.', start: ctx.start, end: ctx.end, confidence: 0.9
    }));
    if (a.length > 125) return mk(Object.assign({}, base, {
      rule: 'a11y.alt-long', severity: 'low', excerpt: ctx.excerpt,
      message: 'Alt text is ' + a.length + ' characters (limit 125)', why: 'Long alt text is tiring to listen to.',
      advice: 'Shorten it; put extra detail in the caption or body text.', start: ctx.start, end: ctx.end, confidence: 0.9
    }));
    return null;
  }

  function checkAccessibilityText(text) {
    const out = [];
    for (const m of text.matchAll(/!\[([^\]]*)\]\(([^)]*)\)/g)) {
      const f = checkAlt(m[1], { start: m.index, end: m.index + m[0].length, excerpt: m[0] });
      if (f) out.push(f);
    }
    for (const m of text.matchAll(/<img\b[^>]*>/gi)) {
      const alt = (m[0].match(/\balt\s*=\s*"([^"]*)"/i) || [])[1];
      const f = checkAlt(alt, { start: m.index, end: m.index + m[0].length, excerpt: m[0].slice(0, 60) });
      if (f) out.push(f);
    }
    for (const m of text.matchAll(/(?<!!)\[(click here|here|read more|this link|link|more|tap here)\]\(([^)]*)\)/gi)) {
      out.push(mk({
        rule: 'a11y.link-text', category: 'accessibility', severity: 'medium',
        refType: 'guideline', refId: 'G-7', guidelineId: 'G-7',
        start: m.index, end: m.index + m[0].length, excerpt: m[0].slice(0, 60),
        message: 'Link text "' + m[1] + '" does not say where it goes',
        why: 'Screen-reader users often list links out of context. "' + m[1] + '" tells them nothing.',
        advice: 'Name the destination, for example "See the Everyday plan details".', confidence: 0.9
      }));
    }
    for (const m of text.matchAll(/#[a-z][a-z0-9]{11,}\b/g)) {
      out.push(mk({
        rule: 'a11y.hashtag', category: 'accessibility', severity: 'low',
        refType: 'guideline', refId: 'G-7', guidelineId: 'G-7',
        start: m.index, end: m.index + m[0].length, excerpt: m[0],
        message: 'Hashtag ' + m[0] + ' is not CamelCase',
        why: 'Screen readers read an all-lowercase hashtag as one unpronounceable word.',
        advice: 'Capitalise each word, for example #DiwaliRecharge.', confidence: 0.7
      }));
    }
    return out;
  }

  /* ---------- checks on an image ---------- */
  function analyzeImage(img, kit) {
    const out = [];
    const v = kit.visual || {};
    const id = img.id || img.name || 'img';
    const label = img.name || 'image';
    const tag = (f) => { f.target = { type: 'image', id, label }; f.refId = f.refId; return f; };
    const alt = checkAlt(img.alt, { excerpt: label });
    if (alt) out.push(tag(alt));

    if (img.role === 'logo' && v.logo) {
      if (img.width && img.width < v.logo.minWidth) out.push(tag(mk({
        rule: 'visual.logo-size', category: 'visual', severity: 'high', refType: 'guideline', refId: 'G-8', guidelineId: 'G-8',
        excerpt: label, message: 'Logo is ' + img.width + 'px wide (minimum ' + v.logo.minWidth + 'px)',
        why: 'Below the minimum the wordmark is not legible.', advice: 'Use the logo at ' + v.logo.minWidth + 'px wide or larger.', confidence: 0.98
      })));
      if (img.width && img.height) {
        const ratio = img.width / img.height;
        if (Math.abs(ratio - v.logo.aspect) / v.logo.aspect > 0.03) out.push(tag(mk({
          rule: 'visual.logo-stretch', category: 'visual', severity: 'high', refType: 'guideline', refId: 'G-8', guidelineId: 'G-8',
          excerpt: label, message: 'Logo looks stretched (ratio ' + ratio.toFixed(2) + ', expected ' + v.logo.aspect.toFixed(2) + ')',
          why: 'The logo must keep its original proportions.', advice: 'Re-export the logo from the asset library at its native ratio.', confidence: 0.9
        })));
      }
      if (img.bgColor && !v.logo.allowedBackgrounds.map((s) => s.toUpperCase()).includes(String(img.bgColor).toUpperCase())) out.push(tag(mk({
        rule: 'visual.logo-bg', category: 'visual', severity: 'medium', refType: 'guideline', refId: 'G-8', guidelineId: 'G-8',
        excerpt: label, message: 'Logo placed on ' + String(img.bgColor).toUpperCase() + ', which is not an approved background',
        why: 'Approved backgrounds: ' + v.logo.allowedBackgrounds.join(', ') + '.', advice: 'Move the logo onto an approved background.', confidence: 0.9
      })));
    }

    if (img.role === 'photo' && v.minPhotoWidth && img.width && img.width < v.minPhotoWidth) out.push(tag(mk({
      rule: 'visual.resolution', category: 'visual', severity: 'low', refType: 'guideline', refId: 'G-8', guidelineId: 'G-8',
      excerpt: label, message: 'Photo is ' + img.width + 'px wide (minimum ' + v.minPhotoWidth + 'px)',
      why: 'Smaller photos look soft on high-density phone screens.', advice: 'Use a larger original.', confidence: 0.8
    })));

    if ((img.role === 'graphic' || img.role === 'logo') && Array.isArray(img.dominant) && v.palette) {
      const pal = v.palette.map((p) => ({ n: p.name, rgb: hexToRgb(p.hex) })).filter((p) => p.rgb);
      for (const d of img.dominant) {
        const rgb = hexToRgb(d.hex);
        if (!rgb || d.share < 0.06) continue;
        const { s, l } = hsl(rgb);
        if (s < 0.25 || l < 0.1 || l > 0.94) continue;
        let best = null;
        for (const p of pal) { const dist = rgbDist(rgb, p.rgb); if (!best || dist < best.dist) best = { dist, n: p.n }; }
        if (best && best.dist > 80) out.push(tag(mk({
          rule: 'visual.palette', category: 'visual', severity: 'medium', refType: 'guideline', refId: 'G-8', guidelineId: 'G-8',
          excerpt: label + ' (' + d.hex.toUpperCase() + ')',
          message: d.hex.toUpperCase() + ' covers ' + Math.round(d.share * 100) + '% of the image and is not in the palette',
          why: 'Nearest palette colour is ' + best.n + ', still ' + Math.round(best.dist) + ' RGB units away.',
          advice: 'Recolour using the approved palette.', confidence: 0.7
        })));
      }
    }

    if (img.textColor && img.bgColor) {
      const c = contrast(img.textColor, img.bgColor);
      const need = v.minContrast || 4.5;
      if (c != null && c < need) {
        let bestHex = null, bestC = 0;
        for (const p of v.palette || []) { const cc = contrast(p.hex, img.bgColor); if (cc > bestC) { bestC = cc; bestHex = p.hex; } }
        out.push(tag(mk({
          rule: 'a11y.contrast', category: 'accessibility', severity: 'high', refType: 'guideline', refId: 'G-8', guidelineId: 'G-8',
          excerpt: label + ' (' + String(img.textColor).toUpperCase() + ' on ' + String(img.bgColor).toUpperCase() + ')',
          message: 'Text contrast is ' + c.toFixed(2) + ':1 (minimum ' + need + ':1)',
          why: 'Low-contrast text is hard to read for many people, especially in sunlight on a phone.',
          advice: bestHex ? 'On this background, ' + bestHex.toUpperCase() + ' from the palette gives ' + bestC.toFixed(1) + ':1.' : 'Use a darker or lighter text colour.',
          confidence: 0.99
        })));
      }
    }
    return out;
  }

  /* ---------- public: analyse ---------- */
  function finish(list) {
    const pos = (f) => (f.start == null ? 1e9 : f.start);
    const sorted = list.slice().sort((a, b) => pos(a) - pos(b) || SEV_RANK[b.severity] - SEV_RANK[a.severity] || b.confidence - a.confidence);
    const seen = new Set();
    const uniq = [];
    for (const f of sorted) {
      // two findings that would rewrite the same span: keep the more severe one
      const k = f.start != null ? f.start + ':' + f.end + ':' + (f.suggestion ? 's' : f.rule) : null;
      if (k && seen.has(k)) continue;
      if (k) seen.add(k);
      uniq.push(f);
    }
    const counts = {};
    for (const f of uniq) {
      const base = [f.rule, f.refId, (f.excerpt || '').toLowerCase(), f.target ? f.target.id : ''].join('|');
      counts[base] = (counts[base] || 0) + 1;
      f.key = base + '|' + counts[base];
    }
    return uniq;
  }

  function analyze(text, kit, opts) {
    opts = opts || {};
    const sents = sentences(text);
    const claims = checkClaims(text, kit, sents, opts);
    const facts = checkFacts(text, kit);
    const findings = finish([].concat(
      checkTerminology(text, kit),
      checkTone(text, kit, sents),
      claims.findings,
      facts.findings,
      checkAccessibilityText(text)
    ));
    return { findings, verified: [].concat(claims.verified, facts.verified) };
  }

  function analyzeVersion(version, kit, opts) {
    const base = analyze(version.text || '', kit, opts);
    const imgs = [];
    for (const im of version.images || []) imgs.push.apply(imgs, analyzeImage(im, kit));
    const all = finish(base.findings.concat(imgs));
    return { findings: all, verified: base.verified };
  }

  /* ---------- public: apply edits ---------- */
  function applyEdits(text, edits) {
    const sorted = edits.filter((e) => e && e.start != null).slice().sort((a, b) => b.start - a.start || b.end - a.end);
    let out = text, lastStart = Infinity;
    const applied = [], skipped = [];
    for (const e of sorted) {
      if (e.end > lastStart) { skipped.push(e); continue; }
      out = out.slice(0, e.start) + e.replacement + out.slice(e.end);
      lastStart = e.start;
      applied.push(e);
    }
    return { text: out, applied, skipped };
  }

  function summarize(findings) {
    const s = { total: findings.length, high: 0, medium: 0, low: 0, byCategory: {} };
    for (const f of findings) { s[f.severity]++; s.byCategory[f.category] = (s.byCategory[f.category] || 0) + 1; }
    return s;
  }

  return { analyze, analyzeVersion, analyzeImage, applyEdits, summarize, sentences, contrast, hexToRgb, rgbToHex, matchCase };
});
