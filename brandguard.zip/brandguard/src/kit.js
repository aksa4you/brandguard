/* Sample brand kit for a fictional organisation (Tarang Mobile).
 * Everything here is invented for the demo; no real company data is used.
 * A real organisation replaces this by importing its own kit JSON in the app. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else { root.BG = root.BG || {}; root.BG.sampleKit = factory(); }
})(typeof self !== 'undefined' ? self : this, function () {
  return {
    org: 'Tarang Mobile (fictional)',
    version: '2026.10',
    guidelines: [
      { id: 'G-1', section: 'Voice', title: 'Warm, plain, direct', text: 'Tarang speaks like a helpful neighbour: warm, plain and direct. We avoid hype words and never shout.' },
      { id: 'G-2', section: 'Terminology', title: 'Preferred terms', text: 'Say "recharge" not "top-up", "plan" not "package", "customers" not "subscribers" or "users", and "Tarang Care" not "customer care" or "helpline".' },
      { id: 'G-3', section: 'Claims', title: 'Evidence for superlatives', text: 'Any superlative or ranking claim ("fastest", "#1", "best") needs an approved evidence entry with scope and date. Use the approved wording and qualifier only.' },
      { id: 'G-4', section: 'Pricing and facts', title: 'Match the plan sheet', text: 'Prices, validity and benefits must match the current plan sheet. Never quote a retired plan.' },
      { id: 'G-5', section: 'Punctuation', title: 'No shouting', text: 'At most one exclamation mark per piece. No ALL-CAPS words except approved acronyms.' },
      { id: 'G-6', section: 'Legal qualifiers', title: 'Required disclaimers', text: '"Unlimited" always carries "Fair usage policy applies". "Free" always carries "T&C apply".' },
      { id: 'G-7', section: 'Accessibility', title: 'Alt text, links, hashtags', text: 'Every image needs meaningful alt text under 125 characters. Link text must describe the destination. Hashtags use CamelCase.' },
      { id: 'G-8', section: 'Logo and colour', title: 'Logo and palette', text: 'Logo minimum width 96px, never stretched, only on approved backgrounds. Use palette colours only. Text contrast must be at least 4.5:1.' },
      { id: 'G-9', section: 'Readability', title: 'Short sentences', text: 'Keep sentences under 25 words.' }
    ],
    terms: [
      { id: 'T-1', preferred: 'recharge', avoid: ['top-up', 'top up', 'topup'], guideline: 'G-2', note: 'Customers search for "recharge".' },
      { id: 'T-2', preferred: 'plan', avoid: ['package', 'bundle'], guideline: 'G-2', note: '' },
      { id: 'T-3', preferred: 'customer', avoid: ['subscriber', 'user'], guideline: 'G-2', note: 'We write about people, not accounts.' },
      { id: 'T-4', preferred: 'Tarang Care', avoid: ['customer care', 'helpline', 'call centre'], guideline: 'G-2', noPlural: true, note: 'Name of the support service.' }
    ],
    tone: {
      maxExclaim: 1,
      maxSentenceWords: 25,
      allowedAcronyms: ['TRAI', 'UPI', 'KYC', 'SIM', 'OTP', 'FAQ', 'FUP', 'IMEI', 'NRI', 'EMI', 'GST', 'LTE'],
      banned: [
        { word: 'cheap', replacement: 'affordable', why: '"Cheap" reads as low quality.' },
        { word: 'amazing', replacement: 'great', why: 'Hype word.' },
        { word: 'mind-blowing', replacement: 'impressive', why: 'Hype word.' },
        { word: 'unbelievable', replacement: 'remarkable', why: 'Hype word.' },
        { word: 'dhamaka', replacement: 'offer', why: 'Slang that does not suit official copy.' }
      ]
    },
    claimRules: [
      { id: 'C-1', label: 'speed superlative', pattern: '\\b(fastest|faster than (?:everyone|anyone|all))\\b', topic: 'fastest-5g', soft: 'fast', guideline: 'G-3' },
      { id: 'C-2', label: 'ranking claim', pattern: '(#\\s?1\\b|\\bno\\.?\\s?1\\b|\\bnumber\\s(?:one|1)\\b)', topic: 'rank-1', soft: 'trusted', guideline: 'G-3' },
      { id: 'C-3', label: 'coverage superlative', pattern: '\\b(best (?:network|coverage)|widest coverage)\\b', topic: 'best-coverage', soft: 'strong coverage', guideline: 'G-3' },
      { id: 'C-4', label: 'price superlative', pattern: '\\b(cheapest|lowest prices?)\\b', topic: 'lowest-price', soft: 'great value', guideline: 'G-3' },
      { id: 'C-5', label: 'guarantee', pattern: '\\b(guaranteed|100% (?:reliable|uptime))\\b', topic: 'guarantee', soft: 'reliable', guideline: 'G-3' },
      { id: 'C-6', label: '"unlimited" qualifier', pattern: '\\bunlimited\\b', requires: 'disclaimer', disclaimer: 'Fair usage policy applies', guideline: 'G-6' },
      { id: 'C-7', label: '"free" qualifier', pattern: '\\bfree\\b', requires: 'disclaimer', disclaimer: 'T&C apply', guideline: 'G-6' }
    ],
    evidence: [
      { id: 'E-1', topic: 'fastest-5g', scope: 'Lucknow', status: 'approved', source: 'TRAI MySpeed report, Q2 2026', expires: '2027-12-31',
        requiredText: 'TRAI MySpeed', approvedWording: 'Based on median 5G download speeds in Lucknow, TRAI MySpeed Q2 2026.' },
      { id: 'E-2', topic: 'best-coverage', scope: 'India', status: 'withdrawn', source: 'Internal coverage audit (withdrawn after review)', expires: '2026-12-31',
        requiredText: 'coverage audit', approvedWording: '' },
      { id: 'E-3', topic: 'rank-1', scope: 'India', status: 'approved', source: 'Customer survey 2025', expires: '2026-06-30',
        requiredText: 'Customer survey 2025', approvedWording: 'Rated #1 in the 2025 customer survey.' }
    ],
    facts: [
      { id: 'F-1', name: 'Everyday plan', aliases: ['everyday plan', 'everyday 299'], status: 'current', price: 299, validityDays: 28, source: 'Plan sheet, Oct 2026' },
      { id: 'F-2', name: 'Weekender plan', aliases: ['weekender plan', 'weekender'], status: 'current', price: 99, validityDays: 7, source: 'Plan sheet, Oct 2026' },
      { id: 'F-3', name: 'Annual Saver plan', aliases: ['annual saver'], status: 'current', price: 3199, validityDays: 365, source: 'Plan sheet, Oct 2026' },
      { id: 'F-4', name: 'Value 249 plan', aliases: ['value 249 plan', 'value 249'], status: 'retired', replacementName: 'Everyday plan', source: 'Retired Sep 2026' }
    ],
    visual: {
      palette: [
        { name: 'Tarang Teal', hex: '#0A7C86' },
        { name: 'Deep Sea', hex: '#0B2B40' },
        { name: 'Saffron', hex: '#F2A33A' },
        { name: 'Mist', hex: '#E8F3F4' },
        { name: 'White', hex: '#FFFFFF' }
      ],
      fonts: ['Poppins', 'Noto Sans'],
      logo: { minWidth: 96, aspect: 3.2, allowedBackgrounds: ['#FFFFFF', '#0B2B40', '#E8F3F4'] },
      minPhotoWidth: 1080,
      minContrast: 4.5
    }
  };
});
