/* End-to-end browser test for dist/brandguard.html.
 * Run:  node scripts/build.js && python3 tests/make_fixtures.py && node tests/e2e.js
 * Needs Playwright with Chromium. Exits 1 if any check fails. */
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.join(__dirname, '..', 'dist', 'brandguard.html');
const FIX = (f) => path.join(__dirname, 'fixtures', f);
const SHOTS = process.env.SHOTS || '';

const results = [];
const check = (name, ok, detail) => { results.push({ name, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + name + (!ok && detail !== undefined ? '  -> ' + JSON.stringify(detail) : '')); };

async function fresh(browser, viewport) {
  const ctx = await browser.newContext({ viewport: viewport || { width: 1360, height: 900 } });
  const page = await ctx.newPage();
  const net = [], errs = [];
  page.on('request', (r) => { if (!/^(file|data|blob|about):/.test(r.url())) net.push(r.url()); });
  page.on('pageerror', (e) => errs.push(e.message));
  await page.goto(FILE);
  await page.waitForSelector('[data-a="run"]');
  return { page, net, errs, ctx };
}
const acceptAll = async (p) => { let n; while ((n = await p.locator('article.finding:not(.decided) [data-a="accept"]').count()) > 0) await p.locator('article.finding:not(.decided) [data-a="accept"]').first().click(); };
const headings = (p) => p.locator('article.finding h4').allTextContents();

(async () => {
  const browser = await chromium.launch();

  /* 1. central path: content in -> checked -> explained -> human decides */
  {
    const { page: p, net, errs, ctx } = await fresh(browser);
    const original = await p.inputValue('#dtext');
    await p.click('[data-a="run"]'); await p.waitForTimeout(300);
    const cards = await p.locator('article.finding').count();
    check('central path: sample draft produces findings', cards >= 10, cards);
    const sources = await p.locator('article.finding .source').allTextContents();
    check('every finding cites a guideline (G-n)', sources.length === cards && sources.every((s) => /G-\d/.test(s)), sources.length);
    check('nothing is changed before a human decides', (await p.locator('#paper').innerText()).replace(/\s+/g, ' ').trim() === original.replace(/\s+/g, ' ').trim());
    check('submit is blocked while findings are open', await p.locator('[data-a="submit"]').isDisabled());
    await acceptAll(p);
    await p.click('[data-a="apply"]'); await p.waitForTimeout(300);
    const t = await p.locator('#paper').innerText();
    check('applied accepted fixes: price, terms and claim corrected', /₹299/.test(t) && /recharge/.test(t) && /customer/.test(t) && !/CHEAP|#1|dhamaka/i.test(t), t);
    check('version history records version 2', /version 2/.test(await p.locator('.doc-head').innerText()));
    if (SHOTS) await p.screenshot({ path: SHOTS + '/review.png', fullPage: true });
    check('no network requests were made', net.length === 0, net);
    check('no script errors', errs.length === 0, errs);

    // reviewer cannot decide on a draft
    await p.selectOption('#role', 'reviewer'); await p.waitForTimeout(200);
    check('reviewer sees no accept/dismiss buttons on a draft', (await p.locator('[data-a="accept"], [data-a="dismissStart"]').count()) === 0);
    await ctx.close();
  }

  /* 2. human-control: an unfixed high-severity finding cannot slip through */
  {
    const { page: p, ctx } = await fresh(browser);
    await p.fill('#dtext', 'Our Everyday plan is ₹299 for 28 days.'); await p.fill('#dt', 'Logo banner');
    await p.setInputFiles('#fimg', FIX('logo-stretched.png')); await p.waitForTimeout(500);
    await p.click('[data-a="run"]'); await p.waitForTimeout(300);
    const hs = await headings(p);
    check('image checks: missing alt text, stretched logo and off-palette colour are found', hs.some((h) => /no alt text/i.test(h)) && hs.some((h) => /stretched/i.test(h)) && hs.some((h) => /not in the palette/i.test(h)), hs);
    // write alt text
    await p.locator('article.finding:has-text("no alt text") [data-a="editStart"]').click();
    await p.locator('input[data-role="edit"]').fill('Tarang Mobile banner with a magenta background');
    await p.locator('[data-a="editSave"]').click();
    await acceptAll(p);
    await p.click('[data-a="apply"]'); await p.waitForTimeout(300);
    await acceptAll(p);
    const blocked = await p.locator('[data-a="submit"]').isDisabled();
    const why = await p.locator('main').innerText();
    check('"I will fix this" on a high-severity finding blocks submission', blocked && /marked “I will fix this” but still present/.test(why), why.slice(0, 300));
    // dismiss with a reason instead
    await p.locator('article.finding:has-text("Logo looks stretched") [data-a="undo"]').click();
    await p.locator('article.finding:has-text("Logo looks stretched") [data-a="dismissStart"]').click();
    await p.locator('[data-a="dismissSave"]').click();
    await acceptAll(p);
    check('dismissing with a reason allows submission', !(await p.locator('[data-a="submit"]').isDisabled()));
    await p.click('[data-a="submit"]'); await p.waitForTimeout(200);
    await p.selectOption('#role', 'reviewer'); await p.waitForTimeout(200);
    check('reviewer must confirm the high-severity dismissal before approving', await p.locator('[data-a="approve"]').isDisabled());
    await p.locator('input[data-ack]').first().check();
    await p.click('[data-a="approve"]'); await p.waitForTimeout(200);
    check('reviewer can approve after sign-off', /Approved/.test(await p.locator('.doc-head .pill').first().innerText()));
    await ctx.close();
  }

  /* 3. request changes needs feedback, then the creator revises */
  {
    const { page: p, ctx } = await fresh(browser);
    await p.fill('#dtext', 'Our Everyday plan is ₹299 for 28 days.');
    await p.click('[data-a="run"]'); await p.waitForTimeout(200);
    check('a clean draft shows no findings', (await p.locator('article.finding').count()) === 0);
    await p.click('[data-a="submit"]'); await p.selectOption('#role', 'reviewer'); await p.waitForTimeout(200);
    await p.click('[data-a="requestChanges"]'); await p.waitForTimeout(100);
    check('request changes without feedback is refused', /In review/.test(await p.locator('.doc-head .pill').first().innerText()));
    await p.fill('#rc', 'Please add the launch date.'); await p.click('[data-a="requestChanges"]'); await p.waitForTimeout(200);
    check('request changes with feedback sends it back', /Changes requested/.test(await p.locator('.doc-head .pill').first().innerText()));
    await p.selectOption('#role', 'creator'); await p.waitForTimeout(200);
    await p.click('[data-a="editText"]'); await p.fill('#etext', 'Our Everyday plan is ₹349 for 28 days.'); await p.click('[data-a="saveText"]'); await p.waitForTimeout(200);
    check('hand edits create a new version and are re-checked (wrong price caught)', (await headings(p)).some((h) => /Price does not match/.test(h)));
    await ctx.close();
  }

  /* 4. document import: PDF and Word */
  {
    const { page: p, net, ctx } = await fresh(browser);
    await p.setInputFiles('#ftxt', FIX('offer.pdf')); await p.waitForTimeout(1500);
    const pdf = await p.inputValue('#dtext');
    check('PDF import extracts the text', /₹279 for 28 days/.test(pdf), pdf);
    check('PDF import joins wrapped lines and keeps paragraph breaks', /CHEAP top-up packages today\. The Everyday plan/.test(pdf) && /\n\n.*Unlimited/.test(pdf), JSON.stringify(pdf));
    await p.click('[data-a="run"]'); await p.waitForTimeout(300);
    const hp = await headings(p);
    check('PDF content is checked (price, term, shouting)', hp.some((h) => /Price does not match/.test(h)) && hp.some((h) => /top-up/.test(h)) && hp.some((h) => /CHEAP/.test(h)), hp);
    await p.click('[data-a="nav"][data-view="new"]');
    await p.setInputFiles('#ftxt', FIX('offer.docx')); await p.waitForTimeout(800);
    const dx = await p.inputValue('#dtext');
    check('Word import extracts the text', /Weekender plan: ₹149/.test(dx) && /fastest 5G/.test(dx), dx);
    await p.click('[data-a="run"]'); await p.waitForTimeout(300);
    const hd = await headings(p);
    check('Word content is checked (price, term, unsupported claim)', hd.some((h) => /₹149 vs ₹99/.test(h)) && hd.some((h) => /helpline/.test(h)) && hd.some((h) => /Unsupported claim|fastest/i.test(h)), hd);
    check('importing documents makes no network requests', net.length === 0, net);
    await ctx.close();
  }

  /* 5. governance: kit changes re-check open reviews; insights are populated */
  {
    const { page: p, ctx } = await fresh(browser);
    await p.click('[data-a="run"]'); await p.waitForTimeout(200);
    await p.selectOption('#role', 'manager'); await p.click('[data-a="nav"][data-view="kit"]'); await p.waitForTimeout(200);
    await p.locator('input[data-kit="fact"][data-field="price"]').first().fill('349'); await p.locator('input[data-kit="fact"][data-field="price"]').first().dispatchEvent('change'); await p.waitForTimeout(200);
    await p.click('[data-a="nav"][data-view="review"]'); await p.waitForTimeout(200);
    check('changing an approved fact re-checks the open review', (await headings(p)).some((h) => /₹279 vs ₹349/.test(h)), await headings(p));
    await p.click('[data-a="nav"][data-view="insights"]'); await p.waitForTimeout(200);
    const ins = await p.locator('main').innerText();
    check('insights show repeated mistakes and unclear guidelines from the history', /Most repeated mistakes/.test(ins) && /Guidelines that may be unclear/.test(ins));
    await ctx.close();
  }

  /* 6. layout: phone width has no sideways scroll; the draft stays in view on desktop */
  {
    const { page: p, ctx } = await fresh(browser, { width: 390, height: 800 });
    await p.click('[data-a="run"]'); await p.waitForTimeout(300);
    for (const v of ['review', 'new', 'queue', 'kit', 'insights', 'about']) {
      if (v !== 'review') { await p.click('[data-a="nav"][data-view="' + v + '"]'); await p.waitForTimeout(150); }
      const w = await p.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]);
      check('phone width: no horizontal scroll on the ' + v + ' screen', w[0] <= w[1] + 1, w);
    }
    await ctx.close();
    const d = await fresh(browser, { width: 1360, height: 800 });
    await d.page.click('[data-a="run"]'); await d.page.waitForTimeout(300);
    await d.page.evaluate(() => window.scrollTo(0, 900)); await d.page.waitForTimeout(150);
    const top = await d.page.evaluate(() => document.querySelector('.sticky-col').getBoundingClientRect().top);
    check('desktop: the draft stays visible while scrolling the findings', top >= 0 && top < 120, top);
    await d.ctx.close();
  }

  await browser.close();
  const failed = results.filter((r) => !r.ok);
  console.log('\n' + (results.length - failed.length) + '/' + results.length + ' checks passed');
  process.exit(failed.length ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
