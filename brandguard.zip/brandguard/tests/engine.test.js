const test = require('node:test');
const assert = require('node:assert/strict');
const BG = require('../src/engine.js');
const kit = require('../src/kit.js');
const opts = { today: '2026-10-27' };

const run = (t) => BG.analyze(t, kit, opts);
const rules = (t) => run(t).findings.map((f) => f.rule);

test('terminology: flags avoided term, keeps case and plural', () => {
  const r = run('Top-up packages for every subscriber.');
  const terms = r.findings.filter((f) => f.rule === 'terminology');
  assert.equal(terms.length, 3);
  const reps = terms.map((f) => f.suggestion.replacement).sort();
  assert.deepEqual(reps, ['Recharge', 'customer', 'plans']);
  assert.ok(terms.every((f) => f.guidelineId === 'G-2'));
});

test('terminology: does not flag inside other words', () => {
  assert.equal(run('Our superuser tools and userland.').findings.filter((f) => f.rule === 'terminology').length, 0);
});

test('tone: banned words, caps and exclamation marks', () => {
  const r = run('Amazing deal!! Grab it TODAY! Hurry!').findings;
  assert.ok(r.some((f) => f.rule === 'tone.banned' && f.excerpt === 'Amazing' && f.suggestion.replacement === 'Great'));
  assert.ok(r.some((f) => f.rule === 'tone.caps' && f.excerpt === 'TODAY'));
  const ex = r.filter((f) => f.rule === 'tone.exclaim');
  assert.ok(ex.length >= 2);
});

test('tone: approved acronyms are not flagged as shouting', () => {
  assert.equal(run('Complete your KYC with your SIM and UPI.').findings.filter((f) => f.rule === 'tone.caps').length, 0);
});

test('tone: long sentences are flagged without an auto-rewrite', () => {
  const long = Array(30).fill('word').join(' ') + '.';
  const f = run(long).findings.find((x) => x.rule === 'clarity.long');
  assert.ok(f);
  assert.equal(f.suggestion, null);
  assert.ok(f.advice);
});

test('claims: unsupported superlative is high severity and softened, not deleted', () => {
  const f = run('We are the cheapest network.').findings.find((x) => x.rule === 'claims.unsupported');
  assert.ok(f);
  assert.equal(f.severity, 'high');
  assert.equal(f.suggestion.replacement, 'great value');
  assert.equal(f.guidelineId, 'G-3');
});

test('claims: approved evidence requires its qualifier; supplied qualifier verifies', () => {
  const bad = run('Tarang has the fastest 5G in Lucknow.').findings.find((x) => x.rule === 'claims.qualifier');
  assert.ok(bad);
  assert.equal(bad.refId, 'E-1');
  assert.ok(bad.suggestion.replacement.includes('TRAI MySpeed'));
  const ok = run('Tarang has the fastest 5G in Lucknow, per TRAI MySpeed Q2 2026.');
  assert.equal(ok.findings.filter((x) => x.rule.startsWith('claims.')).length, 0);
  assert.ok(ok.verified.some((v) => v.refId === 'E-1'));
});

test('claims: expired and withdrawn evidence are reported as such', () => {
  const exp = run("India's #1 network.").findings.find((x) => x.rule === 'claims.unsupported');
  assert.ok(exp.why.includes('expired on 2026-06-30'));
  const wd = run('We have the best network in India.').findings.find((x) => x.rule === 'claims.unsupported');
  assert.ok(wd.why.includes('withdrawn'));
});

test('claims: evidence expiry depends on the review date', () => {
  const t = 'Tarang has the fastest 5G in Lucknow, per TRAI MySpeed Q2 2026.';
  const later = BG.analyze(t, kit, { today: '2028-03-01' }).findings.find((x) => x.rule === 'claims.unsupported');
  assert.ok(later, 'E-1 expires 2027-12-31, so the claim must be flagged afterwards');
});

test('claims: "unlimited" and "free" need their qualifiers, once satisfied they pass', () => {
  const f = rules('Unlimited calls and free SIM delivery.');
  assert.equal(f.filter((r) => r === 'claims.disclaimer').length, 2);
  const ok = run('Unlimited calls. Fair usage policy applies. Free SIM delivery, T&C apply.');
  assert.equal(ok.findings.filter((x) => x.rule === 'claims.disclaimer').length, 0);
  assert.ok(ok.verified.length >= 2);
});

test('facts: wrong price and validity are corrected from the plan sheet', () => {
  const r = run('The Everyday plan is just ₹279 for 30 days.').findings;
  const p = r.find((f) => f.rule === 'facts.price');
  const v = r.find((f) => f.rule === 'facts.validity');
  assert.equal(p.suggestion.replacement, '₹299');
  assert.equal(v.suggestion.replacement, '28 days');
});

test('facts: correct values verify, and a price before the plan name is found', () => {
  const ok = run('The Everyday plan costs ₹299 for 28 days.');
  assert.equal(ok.findings.filter((f) => f.category === 'facts').length, 0);
  assert.equal(ok.verified.length, 2);
  const before = run('Only ₹349 Weekender plan.').findings.find((f) => f.rule === 'facts.price');
  assert.ok(before);
  assert.equal(before.suggestion.replacement, '₹99');
});

test('facts: unrelated amounts far from a plan name are ignored; Indian digit grouping', () => {
  assert.equal(run('Save ₹50 on your next bill. The Everyday plan is simple. Refer a friend and earn ₹100.').findings.filter((f) => f.rule === 'facts.price').length, 0);
  const a = run('Annual Saver plan at ₹2999.').findings.find((f) => f.rule === 'facts.price');
  assert.equal(a.suggestion.replacement, '₹3,199');
});

test('facts: retired plan is flagged with the current replacement', () => {
  const f = run('Switch from the Value 249 plan today.').findings.find((x) => x.rule === 'facts.retired');
  assert.ok(f);
  assert.equal(f.severity, 'high');
  assert.equal(f.suggestion.replacement, 'Everyday plan');
});

test('accessibility in text: alt text, link text, hashtags', () => {
  const t = '![](a.png) ![IMG_2231.jpg](b.png) ![Family using a phone at dinner](c.png) [click here](https://x.in) #diwalirecharge';
  const r = run(t).findings;
  assert.ok(r.some((f) => f.rule === 'a11y.alt-missing'));
  assert.ok(r.some((f) => f.rule === 'a11y.alt-generic'));
  assert.equal(r.filter((f) => f.rule.startsWith('a11y.alt')).length, 2);
  assert.ok(r.some((f) => f.rule === 'a11y.link-text'));
  assert.ok(r.some((f) => f.rule === 'a11y.hashtag'));
});

test('images: logo size, stretch, background, contrast and palette', () => {
  const f = BG.analyzeImage({ id: 'i1', name: 'logo.png', role: 'logo', width: 80, height: 40, alt: 'Tarang Mobile logo', bgColor: '#FF00AA' }, kit).map((x) => x.rule);
  assert.ok(f.includes('visual.logo-size'));
  assert.ok(f.includes('visual.logo-stretch'));
  assert.ok(f.includes('visual.logo-bg'));
  const g = BG.analyzeImage({ id: 'i2', name: 'banner.png', role: 'graphic', alt: 'Offer banner', textColor: '#AAAAAA', bgColor: '#FFFFFF',
    dominant: [{ hex: '#E0245E', share: 0.4 }, { hex: '#0A7C86', share: 0.3 }] }, kit);
  assert.ok(g.some((x) => x.rule === 'a11y.contrast' && /palette/.test(x.advice)));
  assert.equal(g.filter((x) => x.rule === 'visual.palette').length, 1);
  assert.equal(BG.analyzeImage({ id: 'i3', name: 'ok.png', role: 'logo', width: 320, height: 100, alt: 'Tarang Mobile logo', bgColor: '#FFFFFF' }, kit).length, 0);
});

test('contrast ratio matches the WCAG reference values', () => {
  assert.equal(BG.contrast('#000000', '#FFFFFF').toFixed(1), '21.0');
  assert.equal(BG.contrast('#777777', '#FFFFFF').toFixed(2), '4.48');
});

test('applyEdits: applies several edits, including insertions, and skips overlaps', () => {
  const text = 'Top-up now. Cheap deal';
  const r = run(text).findings.filter((f) => f.suggestion);
  const out = BG.applyEdits(text, r.map((f) => f.suggestion));
  assert.equal(out.text, 'Recharge now. Affordable deal');
  const o = BG.applyEdits('abcdef', [{ start: 1, end: 4, replacement: 'X' }, { start: 3, end: 5, replacement: 'Y' }]);
  assert.equal(o.skipped.length, 1);
});

test('end to end: a messy draft is fully clean after applying every suggestion', () => {
  const draft = 'Diwali dhamaka!! Grab our CHEAP top-up packages. The Everyday plan is now just ₹279 for 28 days. Unlimited calls for every subscriber. India\'s #1 network!';
  const first = run(draft);
  assert.ok(first.findings.length >= 10);
  const edits = first.findings.filter((f) => f.suggestion).map((f) => f.suggestion);
  const fixed = BG.applyEdits(draft, edits).text;
  const second = run(fixed);
  assert.deepEqual(second.findings.filter((f) => f.suggestion), [], 'no auto-fixable issues remain: ' + JSON.stringify(second.findings.map((f) => f.rule)));
  assert.ok(second.findings.length < first.findings.length);
});

test('finding keys are stable between runs and unique within one', () => {
  const t = 'Cheap top-up. Cheap top-up.';
  const a = run(t).findings, b = run(t).findings;
  assert.deepEqual(a.map((f) => f.key), b.map((f) => f.key));
  assert.equal(new Set(a.map((f) => f.key)).size, a.length);
});

test('every finding names its source guideline', () => {
  const t = "Cheap TOP-UP!! India's #1 for ₹10 Everyday plan. Unlimited. ![](x.png)";
  for (const f of run(t).findings) assert.ok(f.guidelineId && kit.guidelines.some((g) => g.id === f.guidelineId), f.rule + ' has no valid guideline');
});
