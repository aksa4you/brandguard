"""Creates the sample PDF, DOCX and PNG used by tests/e2e.js. Needs reportlab, python-docx, pillow."""
import os, sys
from PIL import Image, ImageDraw
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import docx

out = os.path.join(os.path.dirname(__file__), 'fixtures'); os.makedirs(out, exist_ok=True)
font = next((p for p in ['/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', '/usr/share/fonts/dejavu/DejaVuSans.ttf'] if os.path.exists(p)), None)
if not font: sys.exit('DejaVuSans.ttf not found (needed for the rupee sign)')
pdfmetrics.registerFont(TTFont('DejaVu', font))

c = canvas.Canvas(os.path.join(out, 'offer.pdf')); c.setFont('DejaVu', 12)
lines = ['Diwali dhamaka! Grab our CHEAP top-up packages today.',   # one paragraph wrapped over two lines
         'The Everyday plan is now just ₹279 for 28 days.', None,
         'Unlimited calls for every subscriber.']
y = 780
for ln in lines:
    if ln is None: y -= 26; continue
    c.drawString(60, y, ln); y -= 16
c.save()

d = docx.Document(); d.add_paragraph('Weekender plan: ₹149 for 7 days. Our helpline is open all day.'); d.add_paragraph('Tarang has the fastest 5G in Lucknow.')
d.save(os.path.join(out, 'offer.docx'))

im = Image.new('RGB', (640, 360), (200, 30, 120)); ImageDraw.Draw(im).rectangle((20, 20, 200, 80), fill=(255, 255, 255)); im.save(os.path.join(out, 'logo-stretched.png'))
print('fixtures written to', out)
